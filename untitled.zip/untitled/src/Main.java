import java.util.Random;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        //printNumber();
        //printSum();
        //printAre();
        //printPlo();
        //printChe();
        //printFuck();
        //printAlt();
        //printUmn();
        //primBin();
        //sprimMax();
        //sprimNn();
        //sprinPaali();
        //sprindrom();
        //Sprimkv();
        //Sprinsummvse();
        //SorinRet();
        //SprinSover();
        //SpriNOD();
        //SprinMintwo();
        //SprinRest();
        //SprinHung();
        //sprinTwoMath();
        //sprinFibon();
        //sprinMassiv();
        //sprinArProgSum();
        //sprinHungTen();
        //sprinCheNeche();
        sprinTcikl();
    }

    public static void printNumber() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        System.out.println(a);
        scanner.close();
    }

    public static void printSum() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int result = (a + b);
        System.out.println("Сумма a и b = " + result);

        scanner.close();
    }


    public static void printAre() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();
        int result = (a + b + c) / 3;
        System.out.println("Арифметическое от a b c = " + result);
    }

    public static void printPlo() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int result = a * b;
        System.out.println("Площадь прямоугольника " + result);
    }

    public static void printChe() {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        if (a % 2 == 0) {
            System.out.println("Четное");
        } else {
            if ((a % 2) > 0) {
                System.out.println("Нечетное");
            }
        }
    }

    public static void printFuck() {
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        long factorial = 1;
        if (number < 0) {
        } else {
            for (int i = 1; i <= number; i++) {
                factorial *= i;
            }
            System.out.println("Факториал " + number + "! равен " + factorial);
        }
    }

    public static void printAlt() {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if (a % 2 == 0) {
            System.out.println("Число является действительным");
        } else if (a % 2 != 0) {
            System.out.println("Число не является действительным");
        }
    }

    public static void printUmn() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число");
        int a = scanner.nextInt();
        for (int i = 1; i <= 10; i++) {
            System.out.println(a + "x" + i + "=" + (a * i));
        }
    }

    public static void primBin() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число, чтобы перевести его в двоичный код");
        int a = scanner.nextInt();
        String binaryString = Integer.toBinaryString(a);
        System.out.println("Бинарное представление:" + binaryString);
    }

    public static void sprimMax() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое число");
        int a = scanner.nextInt();
        System.out.println("Введите второе чилсло");
        int b = scanner.nextInt();
        System.out.println("Введите третье число");
        int c = scanner.nextInt();
        int max = a;
        if (b > max) {
            max = b;
        }
        if (c > max) {
            max = c;
        }
        System.out.println("Максимальное число:" + max);
    }

    public static void sprimNn() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите целое число N: ");
        int N = scanner.nextInt();

        int sum = 0;
        for (int i = 1; i <= N; i++) {
            sum += i;
        }

        System.out.println("Сумма всех целых чисел от 1 до " + N + " равна: " + sum);
    }


    public static void  sprinPaali() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите число: ");
        int number = scanner.nextInt();

        if (isPalindrome(number)) {
            System.out.println(number + " является палиндромом.");
        } else {
            System.out.println(number + " не является палиндромом.");
        }

        scanner.close();
    }

    public static boolean isPalindrome(int number) {
        int originalNumber = number;
        int reversedNumber = 0;

        while (number != 0) {
            int digit = number % 10;
            reversedNumber = reversedNumber * 10 + digit;
            number /= 10;
        }

        return originalNumber == reversedNumber;
    }


    public static void Sprimkv() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите положительное число: ");
        double number = scanner.nextDouble();

        if (number < 0) {
            System.out.println("Ошибка: введите положительное число.");
        } else {
            double squareRoot = Math.sqrt(number);
            System.out.println("Квадратный корень из " + number + " равен " + squareRoot);
        }

    }

    public static void Sprinsummvse() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите целое число: ");
        String input = scanner.nextLine();

        int sum = 0;

        for (char c : input.toCharArray()) {
            if (Character.isDigit(c)) {
                sum += Character.getNumericValue(c);
            }
        }

        System.out.println("Сумма всех цифр в числе: " + sum);

        scanner.close();
    }

    public static void SorinRet() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число: ");
        String number = scanner.nextLine();

        String reversedNumber = new StringBuilder(number).reverse().toString();

        System.out.println("Перевернутое число: " + reversedNumber);
    }

    public static void SprinSover() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число: ");
        int number = scanner.nextInt();

        if (isPerfectNumber(number)) {
            System.out.println(number + " является совершенным числом.");
        } else {
            System.out.println(number + " не является совершенным числом.");
        }

    }

    public static boolean isPerfectNumber(int num) {
        if (num < 1) {
            return false;
        }

        int sum = 0;

        for (int i = 1; i <= num / 2; i++) {
            if (num % i == 0) {
                sum += i;
            }
        }

        return sum == num;
    }

    public static void SpriNOD() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите первое целое число: ");
        int a = scanner.nextInt();

        System.out.print("Введите второе целое число: ");
        int b = scanner.nextInt();

        int gcd = gcd(a, b);

        System.out.println("Наибольший общий делитель (" + a + ", " + b + ") = " + gcd);

    }

    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static void SprinMintwo() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите первое число: ");
        int firstNumber = scanner.nextInt();

        System.out.print("Введите второе число: ");
        int secondNumber = scanner.nextInt();

        int minNumber = Math.min(firstNumber, secondNumber);

        System.out.println("Меньшее из двух чисел: " + minNumber);

    }

    public static void SprinRest() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число: ");
        double number = scanner.nextDouble();

        double changedSignNumber = number * -1; // Изменяем знак

        System.out.println("Число с измененным знаком: " + changedSignNumber);

    }

    public static void SprinHung() {
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1; // Генерируем случайное число от 1 до 100
        int userGuess = 0;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Угадайте число от 1 до 100:");

        while (userGuess != randomNumber) {
            System.out.print("Введите ваше число: ");
            userGuess = scanner.nextInt();

            if (userGuess < randomNumber) {
                System.out.println("Загаданное число больше вашего.");
            } else if (userGuess > randomNumber) {
                System.out.println("Загаданное число меньше вашего.");
            } else {
                System.out.println("Поздравляем! Вы угадали число: " + randomNumber);
            }
        }
    }


    public static void sprinTwoMath() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество строк первой матрицы: ");
        int rowsA = scanner.nextInt();
        System.out.print("Введите количество столбцов первой матрицы: ");
        int colsA = scanner.nextInt();

        System.out.print("Введите количество строк второй матрицы: ");
        int rowsB = scanner.nextInt();
        System.out.print("Введите количество столбцов второй матрицы: ");
        int colsB = scanner.nextInt();

        if (colsA != rowsB) {
            System.out.println("Ошибка: Количество столбцов первой матрицы должно быть равно количеству строк второй матрицы.");
            return;
        }

        int[][] matrixA = new int[rowsA][colsA];
        System.out.println("Введите элементы первой матрицы:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsA; j++) {
                matrixA[i][j] = scanner.nextInt();
            }
        }

        int[][] matrixB = new int[rowsB][colsB];
        System.out.println("Введите элементы второй матрицы:");
        for (int i = 0; i < rowsB; i++) {
            for (int j = 0; j < colsB; j++) {
                matrixB[i][j] = scanner.nextInt();
            }
        }

        int[][] resultMatrix = new int[rowsA][colsB];
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA; k++) {
                    resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
                }
            }
        }

        System.out.println("Результат умножения матриц:");
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                System.out.print(resultMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void sprinFibon() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество чисел Фибоначчи (N): ");
        int N = scanner.nextInt();

        if (N <= 0) {
            System.out.println("Ошибка: N должно быть положительным числом.");
            return;
        }

        int[] fibonacciNumbers = new int[N];
        if (N > 0) {
            fibonacciNumbers[0] = 0;
        }
        if (N > 1) {
            fibonacciNumbers[1] = 1;
        }
        for (int i = 2; i < N; i++) {
            fibonacciNumbers[i] = fibonacciNumbers[i - 1] + fibonacciNumbers[i - 2];
        }

        System.out.println("Первые " + N + " чисел Фибоначчи:");
        for (int i = 0; i < N; i++) {
            System.out.print(fibonacciNumbers[i] + " ");
        }
    }

    public static void sprinMassiv() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество элементов в массиве: ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("Ошибка: Количество элементов должно быть положительным числом.");
            return;
        }

        int[] array = new int[n];
        System.out.println("Введите элементы массива:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        bubbleSort(array);

        System.out.println("Отсортированный массив:");
        for (int i = 0; i < n; i++) {
            System.out.print(array[i] + " ");
        }

        scanner.close();
    }

    public static void bubbleSort(int[] array) {
        int n = array.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    }

    public static void sprinArProgSum() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите первый член арифметической прогрессии (a1): ");
        double a1 = scanner.nextDouble();

        System.out.print("Введите разность прогрессии (d): ");
        double d = scanner.nextDouble();

        System.out.print("Введите количество членов прогрессии (N): ");
        int N = scanner.nextInt();

        double sum = calculateSum(a1, d, N);
        System.out.println("Сумма первых " + N + " членов арифметической прогрессии: " + sum);
    }
    public static double calculateSum(double a1, double d, int N) {
        // Формула суммы первых N членов арифметической прогрессии:
        // S_N = N/2 * (2*a1 + (N-1)*d)
        return N / 2.0 * (2 * a1 + (N - 1) * d);
    }

    public static void sprinHungTen() {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int secretNumber = random.nextInt(100) + 1;
        int attempts = 10;
        boolean guessedCorrectly = false;

        System.out.println("Добро пожаловать в игру 'Угадай число'!");
        System.out.println("Я загадал число от 1 до 100. Попробуй угадать его за 10 попыток.");

        while (attempts > 0 && !guessedCorrectly) {
            System.out.print("Введите ваше предположение: ");
            int guess = scanner.nextInt();

            if (guess == secretNumber) {
                guessedCorrectly = true;
                System.out.println("Поздравляю! Вы угадали число!");
            } else if (guess < secretNumber) {
                System.out.println("Загаданное число больше.");
            } else {
                System.out.println("Загаданное число меньше.");
            }

            attempts--;
            System.out.println("Осталось попыток: " + attempts);
        }
        if (!guessedCorrectly) {
            System.out.println("К сожалению, вы не угадали число. Загаданное число было: " + secretNumber);
        }
    }

    public static void  sprinCheNeche() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите целое число: ");
        int number = scanner.nextInt();

        int evenCount = 0;
        int oddCount = 0;

        number = Math.abs(number);

        while (number != 0) {
            int digit = number % 10;
            if (digit % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
            number /= 10;
        }

        System.out.println("Количество четных цифр: " + evenCount);
        System.out.println("Количество нечетных цифр: " + oddCount);

    }

    public static void sprinTcikl() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество элементов в массиве: ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("Ошибка: Количество элементов должно быть положительным числом.");
            return;
        }

        int[] array = new int[n];
        System.out.println("Введите элементы массива:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.print("Введите количество позиций для поворота: ");
        int positions = scanner.nextInt();

        rotateArray(array, positions);

        System.out.println("Повернутый массив:");
        for (int i = 0; i < n; i++) {
            System.out.print(array[i] + " ");
        }

        scanner.close();
    }
    public static void rotateArray(int[] array, int positions) {
        int n = array.length;
        positions = positions % n;
        if (positions < 0) {
            positions = (n + positions % n) % n;
        }

        int[] tempArray = new int[n];
        for (int i = 0; i < n; i++) {
            tempArray[(i + positions) % n] = array[i];
        }

        System.arraycopy(tempArray, 0, array, 0, n);
    }
}










